create definer = jroux@`chapman.edu`@`%` view avgStats as
select `jroux_db`.`Team`.`UniversityName`      AS `UniversityName`,
       round(avg(`s`.`Goals`), 0)              AS `ROUND(AVG(s.Goals),0)`,
       round(avg(`s`.`Assists`), 0)            AS `ROUND(AVG(s.Assists),0)`,
       round(avg(`s`.`MinutesPlayedTotal`), 0) AS `ROUND(AVG(s.MinutesPlayedTotal),0)`,
       round(avg(`s`.`GamesPlayedIn`), 0)      AS `ROUND(AVG(s.GamesPlayedIn),0)`
from ((`jroux_db`.`Team` join `jroux_db`.`Player` `p` on ((`p`.`TeamId` = `jroux_db`.`Team`.`TeamId`)))
         join `jroux_db`.`Stats` `s` on ((`s`.`PlayerId` = `p`.`PlayerId`)))
where (`p`.`isDeleted` = FALSE)
group by `jroux_db`.`Team`.`UniversityName`;

