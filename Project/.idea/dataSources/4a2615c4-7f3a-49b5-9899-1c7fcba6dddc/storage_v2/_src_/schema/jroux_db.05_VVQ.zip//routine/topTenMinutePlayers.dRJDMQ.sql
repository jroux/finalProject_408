create
    definer = jroux@`chapman.edu`@`%` procedure topTenMinutePlayers()
begin
    SELECT Player.Name, Player.JerseyNumber, Player.Position, Stats.MinutesPlayedTotal, Team.UniversityName
    FROM Player
    JOIN Stats ON Stats.PlayerID = Player.PlayerId
    JOIN Team ON Player.TeamId = Team.TeamId
    WHERE Stats.isDeleted = false
    ORDER BY MinutesPlayedTotal DESC LIMIT 11;
    end;

