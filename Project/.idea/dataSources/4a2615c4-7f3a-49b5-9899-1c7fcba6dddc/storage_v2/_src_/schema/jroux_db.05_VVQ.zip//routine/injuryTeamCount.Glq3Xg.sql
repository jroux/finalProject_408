create
    definer = jroux@`chapman.edu`@`%` procedure injuryTeamCount()
begin
    SELECT COUNT(*), Team.UniversityName
    FROM Player
    JOIN Team ON Player.TeamId = Team.TeamId
    WHERE Player.isDeleted = false and Player.Injured = 1
    GROUP BY UniversityName
    ORDER BY Count(*);
end;

