create definer = jroux@`chapman.edu`@`%` view playersAndTeams as
select `p`.`Name`           AS `Name`,
       `a`.`Gpa`            AS `Gpa`,
       `t`.`UniversityName` AS `UniversityName`,
       `p`.`JerseyNumber`   AS `JerseyNumber`,
       `p`.`Year`           AS `Year`,
       `t`.`Wins`           AS `Wins`,
       `t`.`Losses`         AS `Losses`,
       `t`.`Ties`           AS `Ties`,
       `p`.`Injured`        AS `Injured`
from ((`jroux_db`.`Academics` `a` join `jroux_db`.`Player` `p` on ((`a`.`PlayerId` = `p`.`PlayerId`)))
         join `jroux_db`.`Team` `t` on ((`t`.`TeamId` = `p`.`TeamId`)))
where (`a`.`isDeleted` = FALSE);

