create
    definer = jroux@`chapman.edu`@`%` procedure createPlayer(IN userPlayerName varchar(50), IN userJerseyNumber int,
                                                             IN userYear int, IN userPosition varchar(50),
                                                             IN userInjured int, IN userMajor varchar(50),
                                                             IN userGpa float, IN userGoals int, IN userAssists int,
                                                             IN userMinutesPlayed int, IN userGamesPlayed int,
                                                             IN userPlayerUniversity varchar(50))
begin
    DECLARE should_rollback BOOL DEFAULT FALSE;
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET should_rollback = True;
    start transaction;
    INSERT INTO Player (Name, JerseyNumber,Year, Position, Injured)
    VALUES (userPlayerName, userJerseyNumber, userYear, userPosition, userInjured);

    INSERT INTO Academics (Major, Gpa)
    VALUES (userMajor, userGpa);

    INSERT INTO Stats (Goals, Assists, MinutesPlayedTotal, GamesPlayedIn)
    VALUES (userGoals, userAssists, userMinutesPlayed, userGamesPlayed);

    UPDATE Player
    SET TeamId= (
        select TeamId
        from Team
        where TeamId = userPlayerUniversity)
    WHERE Name = userPlayerName;

    UPDATE Stats
    SET PlayerId = (
        select PlayerId
        from Player
        where Name = userPlayerName
        )
    WHERE Goals = userGoals and Assists = userAssists and MinutesPlayedTotal = userMinutesPlayed and GamesPlayedIn = userGamesPlayed; #not sure how to get the exact statsid

    UPDATE Academics
    SET PlayerId = (
        select PlayerId
        from Player
        where Name = userPlayerName
        )
    WHERE Major = userMajor and Gpa = userGpa; #not sure how to get the exact statsid


    IF should_rollback THEN
        ROLLBACK;
    ELSE
        COMMIT;
    end if;
end;

