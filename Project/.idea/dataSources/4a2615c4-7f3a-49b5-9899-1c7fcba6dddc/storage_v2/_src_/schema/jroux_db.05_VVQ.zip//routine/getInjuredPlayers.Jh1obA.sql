create
    definer = jroux@`chapman.edu`@`%` procedure getInjuredPlayers()
begin
    select Name, JerseyNumber, UniversityName
    from Player p
    join Team t ON t.TeamId = p.TeamId
    where Injured = 1 and p.isDeleted = false;
end;

