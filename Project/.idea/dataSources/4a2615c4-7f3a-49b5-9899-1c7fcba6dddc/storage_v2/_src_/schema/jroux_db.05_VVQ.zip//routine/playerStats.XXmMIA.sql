create
    definer = jroux@`chapman.edu`@`%` procedure playerStats()
begin
    select Name, JerseyNumber, UniversityName, MinutesPlayedTotal, GamesPlayedIn, goals, assists
    from Stats
    join Player p ON p.PlayerId = Stats.PlayerId
    join Team t ON t.TeamId = p.TeamId
    where p.isDeleted = false
    order by UniversityName;
end;

