create
    definer = jroux@`chapman.edu`@`%` procedure getEligibilePlayers()
begin
    select Name, Gpa, UniversityName
    from Academics a
    join Player p ON a.PlayerId = p.PlayerId
    join Team t ON t.TeamId = p.TeamId
    where Gpa > 2.5 and a.isDeleted = false;
end;

