create
    definer = jroux@`chapman.edu`@`%` procedure getMostExperiencedCoaches()
begin
    select CoachName, YearsCoached, UniversityName
    from Coach c
    join Team t ON t.CoachId = c.CoachId
    where c.isDeleted = false
    order by YearsCoached desc;
end;

