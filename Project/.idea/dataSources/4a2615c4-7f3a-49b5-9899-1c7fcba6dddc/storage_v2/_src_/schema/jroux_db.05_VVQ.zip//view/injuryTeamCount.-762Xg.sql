create definer = jroux@`chapman.edu`@`%` view injuryTeamCount as
select count(0) AS `COUNT(*)`, `jroux_db`.`Team`.`UniversityName` AS `UniversityName`
from (`jroux_db`.`Player`
         join `jroux_db`.`Team` on ((`jroux_db`.`Player`.`TeamId` = `jroux_db`.`Team`.`TeamId`)))
where ((`jroux_db`.`Player`.`isDeleted` = FALSE) and (`jroux_db`.`Player`.`Injured` = 1))
group by `jroux_db`.`Team`.`UniversityName`;

