create
    definer = jroux@`chapman.edu`@`%` procedure createCoach(IN userCoachName varchar(50), IN userAlmaMater varchar(50),
                                                            IN userYearsCoached varchar(50))
begin
start transaction;
INSERT INTO Coach (CoachName, AlmaMater,YearsCoached)
VALUES (userCoachName, userAlmaMater, userYearsCoached);
commit;
end;

