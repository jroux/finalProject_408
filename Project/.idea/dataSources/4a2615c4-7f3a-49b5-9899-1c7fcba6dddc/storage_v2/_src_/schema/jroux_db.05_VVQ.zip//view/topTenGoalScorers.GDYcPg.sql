create definer = jroux@`chapman.edu`@`%` view topTenGoalScorers as
select `jroux_db`.`Player`.`Name`         AS `Name`,
       `jroux_db`.`Player`.`JerseyNumber` AS `JerseyNumber`,
       `jroux_db`.`Player`.`Position`     AS `Position`,
       `jroux_db`.`Stats`.`Goals`         AS `Goals`,
       `jroux_db`.`Team`.`UniversityName` AS `UniversityName`
from ((`jroux_db`.`Player` join `jroux_db`.`Stats` on ((`jroux_db`.`Stats`.`PlayerId` = `jroux_db`.`Player`.`PlayerId`)))
         join `jroux_db`.`Team` on ((`jroux_db`.`Player`.`TeamId` = `jroux_db`.`Team`.`TeamId`)))
where (`jroux_db`.`Stats`.`isDeleted` = FALSE)
order by `jroux_db`.`Stats`.`Goals` desc
limit 11;

