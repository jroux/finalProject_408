create
    definer = jroux@`chapman.edu`@`%` procedure playersFromSchool(IN userTeamName int)
begin
    select Name, JerseyNumber, Year, Position, UniversityName
    from Player p
    join Team t ON t.TeamId = p.TeamId
    where t.TeamId = userTeamName and p.isDeleted = false;
end;

