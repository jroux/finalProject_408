create
    definer = jroux@`chapman.edu`@`%` procedure createCoach(IN userCoachName varchar(50), IN userAlmaMater varchar(50),
                                                            IN userYearsCoached varchar(50),
                                                            IN userCoachUniversity varchar(50))
begin
start transaction;
INSERT INTO Coach (CoachName, AlmaMater,YearsCoached)
VALUES (userCoachName, userAlmaMater, userYearsCoached);

UPDATE Team
SET CoachId= (
    select CoachId
    from Coach
    where CoachName = userCoachName)
WHERE TeamId = userCoachUniversity;

    commit;

# if userTeamCoach != 'Chapman' then
# rollback;
# end if;
end;

