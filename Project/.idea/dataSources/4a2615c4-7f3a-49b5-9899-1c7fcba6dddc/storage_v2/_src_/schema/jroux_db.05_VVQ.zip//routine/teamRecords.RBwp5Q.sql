create
    definer = jroux@`chapman.edu`@`%` procedure teamRecords()
begin
    select UniversityName, Wins, Losses, Ties
    from Team t
    order by Wins desc;
end;

