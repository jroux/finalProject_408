create
    definer = jroux@`chapman.edu`@`%` procedure avgStats()
begin
    SELECT Team.UniversityName, ROUND(AVG(s.Goals),0), ROUND(AVG(s.Assists),0), ROUND(AVG(s.MinutesPlayedTotal),0), ROUND(AVG(s.GamesPlayedIn),0)
    FROM Team
    JOIN Player p ON p.TeamId = Team.TeamId
    JOIN Stats s ON s.PlayerId = p.PlayerId
    WHERE p.isDeleted = false
    GROUP BY UniversityName;
end;

