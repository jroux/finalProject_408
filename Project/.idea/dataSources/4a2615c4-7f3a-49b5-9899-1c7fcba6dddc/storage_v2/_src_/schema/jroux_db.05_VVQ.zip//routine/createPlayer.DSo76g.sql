create
    definer = jroux@`chapman.edu`@`%` procedure createPlayer(IN userPlayerName varchar(50),
                                                             IN userJerseyNumber varchar(50), IN userYear varchar(50),
                                                             IN userPosition varchar(50), IN userInjured varchar(50),
                                                             IN userMajor varchar(50), IN userGpa int, IN userGoals int,
                                                             IN userAssists int, IN userMinutesPlayed int,
                                                             IN userGamesPlayed int,
                                                             IN userPlayerUniversity varchar(50))
begin
start transaction;
INSERT INTO Player (Name, JerseyNumber,Year, Position, Injured)
VALUES (userPlayerName, userJerseyNumber, userYear, userPosition, userInjured);

INSERT INTO Academics (Major, Gpa)
VALUES (userMajor, userGpa);

INSERT INTO Stats (Goals, Assists, MinutesPlayedTotal, GamesPlayedIn)
VALUES (userGoals, userAssists, userMinutesPlayed, userGamesPlayed);

UPDATE Player
SET TeamId= (
    select TeamId
    from Team
    where TeamId = userPlayerUniversity)
WHERE Name = userPlayerName;

UPDATE Stats
SET PlayerId = (
    select PlayerId
    from Player
    where Name = userPlayerName
    )
WHERE Goals = userGoals and Assists = userAssists and MinutesPlayedTotal = userMinutesPlayed and GamesPlayedIn = userGamesPlayed; #not sure how to get the exact statsid

UPDATE Academics #need to do for academics too
SET PlayerId = (
    select PlayerId
    from Player
    where Name = userPlayerName
    )
WHERE Major = userMajor and Gpa = userGpa; #not sure how to get the exact statsid

commit;
end;

