create
    definer = jroux@`chapman.edu`@`%` procedure getPlayersByYear(IN userYearInput int)
begin
    select Name, Year, JerseyNumber, UniversityName
    from Player p
    join Team t ON t.TeamId = p.TeamId
    where Year = userYearInput and p.isDeleted = false
    order by UniversityName;
end;

